<!DOCTYPE html>
<?php session_start();

	$name=$_SESSION['username'];
	//echo "Hello! ".$name;
?>

<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Item Quotation</title>
	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="assets/header-basic-light.css">
	<link href='http://fonts.googleapis.com/css?family=Cookie' rel='stylesheet' type='text/css'>
	
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-responsive.min.css">
	<script src="js/jquery-2.2.2.js" type="text/javascript"></script>
	<script src="js/jquery-2.2.2.min.js" type="text/javascript"></script>
	
	
</head>
<body>

<header class="header-basic-light">

	<div class="header-limiter">

		<h1><a href="index.php">Happy<span>monk</span></a></h1>
		<nav>
			<a href="lineItem.php">Add Item</a>
			<a href="Quotation" class="selected">Quotation</a>
			<a href="Index.php">Login</a>
			<a href="Register.php">Register Now</a>
			<a href="#">Contact</a>
		</nav>
	</div>

</header>
<div class="container-fluid">
<h1>Item Quotation</h1>
<?php
	include 'dbCon.php';			
    $query="SELECT * FROM `estimate` where username='$name'";
    
    // Execute the query (the recordset $rs contains the result)
	$rs = mysql_query($query);
	
	?>

	<table class="table table-bordered">
			<tr>
				<th>Product Type</th>
				<th>Subtotal</th>
				<th>VAT</th>
				<th>Total</th>
				<th>Action</th>
			</tr>
			<?php
	// Loop the recordset $rs
	while($row = mysql_fetch_array($rs)) {
		?>
			<tr>
				<td><?php echo $row['lineId'];?></td>
				<td><?php echo $row['subtotal'];?>"</td>
				<td><?php echo $row['vat'];?>"</td>
				<td><?php echo $row['t_amount'];?></td>
				<td><a href="producttype/wallpaper.php?Id=<?php echo $row["Id"]; ?>">View</a> | <a href="deleteItem.php?Id=<?php echo $row["Id"]; ?>">Delete</a> | <a href="editItem.php?Id=<?php echo $row["Id"]; ?>">Edit</a> </td>
			</tr>		
<?php }?>

</table>
</div>
</body>
</html>
		